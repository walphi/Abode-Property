import React from 'react';
import { SlideData } from '../types';

interface SlideProps {
  data: SlideData;
}

const renderLayout = (data: SlideData) => {
  switch (data.layout) {
    case 'title':
      return (
        <div className="relative w-full h-full text-white flex flex-col justify-center">
          <div className="absolute inset-0 bg-black opacity-50"></div>
          <img src={data.backgroundImage} alt="background" className="absolute inset-0 w-full h-full object-cover -z-10" />
          <div className="relative z-10 grid grid-cols-12 h-full">
            <div className="col-span-12 md:col-span-7 lg:col-span-5 bg-gray-800 bg-opacity-80 p-8 md:p-12 flex flex-col justify-between">
              <div>
                <div className="w-16 h-1 bg-orange-500 mb-8"></div>
                <h1 className="font-serif text-3xl md:text-4xl lg:text-5xl leading-tight mb-8">{data.title}</h1>
              </div>
              <div className="text-gray-300 text-sm md:text-base">
                <p className="mb-2">{data.preparedFor}</p>
                <p>{data.preparedBy}</p>
              </div>
            </div>
          </div>
        </div>
      );

    case 'index':
      return (
        <div className="w-full h-full bg-orange-600 text-white p-8 md:p-16 lg:p-20 flex flex-col justify-center">
            <h2 className="font-serif text-5xl sm:text-6xl md:text-7xl lg:text-8xl mb-8 md:mb-16">{data.title}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-4 text-xl md:text-2xl">
              {data.listItems?.map((item, index) => (
                <p key={index}>{item}</p>
              ))}
            </div>
        </div>
      );

    case 'overview':
      return (
        <div className="w-full h-full bg-white flex flex-col">
            <div className="flex-grow p-8 md:p-16 lg:p-20">
                <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl mb-8 md:mb-12 text-gray-800 after:content-[''] after:block after:w-24 after:h-1 after:bg-gray-800 after:mt-4">{data.title}</h2>
                <div className="space-y-6 text-gray-600 text-base md:text-lg max-w-4xl">
                  {Array.isArray(data.content) ? data.content.map((p, i) => <p key={i}>{p}</p>) : <p>{data.content}</p>}
                </div>
            </div>
            <div className="h-1/2 md:h-1/3 w-full">
                <img src={data.backgroundImage} alt="overview" className="w-full h-full object-cover" />
            </div>
        </div>
      );

    case 'section_header':
        return (
          <div className="w-full h-full bg-white text-gray-800 p-8 md:p-16 lg:p-20 flex flex-col justify-center">
              <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl mb-8 md:mb-12 after:content-[''] after:block after:w-24 after:h-1 after:bg-gray-800 after:mt-4">{data.title}</h2>
              <div className="space-y-4 text-gray-600 text-base md:text-lg max-w-4xl">
                {Array.isArray(data.content) ? data.content.map((p, i) => <p key={i}>{p}</p>) : <p>{data.content}</p>}
              </div>
          </div>
        );

    case 'phase_detail':
        return (
            <div className="relative w-full h-full text-white flex items-center">
              <div className="absolute inset-0 bg-black opacity-60"></div>
              <img src={data.backgroundImage} alt="background" className="absolute inset-0 w-full h-full object-cover -z-10 filter grayscale" />
              <div className="relative z-10 w-full p-8 md:p-12 lg:p-20 grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 items-center">
                <div className="text-left md:text-right">
                  <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl mb-2">{data.title}</h2>
                  <p className="text-orange-400 text-xl sm:text-2xl">Phase {data.phase?.number}: {data.phase?.title}</p>
                </div>
                <div>
                  <div className="mb-6 text-sm sm:text-base">
                    <h3 className="font-bold text-lg text-gray-300">Duration: <span className="font-normal">{data.phase?.duration}</span></h3>
                    <h3 className="font-bold text-lg text-gray-300">Core Focus: <span className="font-normal">{data.phase?.focus}</span></h3>
                  </div>
                  <h4 className="font-bold text-xl mb-3 text-orange-400">Key Deliverables:</h4>
                  <ul className="list-disc list-inside space-y-2 text-gray-200 text-sm sm:text-base">
                    {data.phase?.deliverables.map((item, index) => (
                      <li key={index}>{item}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
        );
        
    case 'simple_dark':
      return (
        <div className="w-full h-full bg-gray-800 text-white p-8 md:p-16 lg:p-20 flex flex-col justify-center">
          <div className="w-16 h-1 bg-orange-500 mb-8"></div>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl mb-12">{data.title}</h2>
          <div className="space-y-6 max-w-5xl font-serif text-xl md:text-2xl text-gray-300 leading-relaxed">
            {Array.isArray(data.content) ? data.content.map((p, i) => <p key={i}>{p}</p>) : <p>{data.content}</p>}
          </div>
        </div>
      );

    case 'agreement':
        return (
            <div className="w-full h-full bg-white text-gray-800 p-8 md:p-16 lg:p-20 flex flex-col justify-center">
                <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl mb-8 md:mb-12 after:content-[''] after:block after:w-24 after:h-1 after:bg-gray-800 after:mt-4">{data.title}</h2>
                <p className="max-w-5xl text-base md:text-lg text-gray-600 mb-12 md:mb-16">{data.agreementDetails?.text}</p>
                <div className="flex flex-col md:flex-row justify-between items-start max-w-5xl gap-12 md:gap-4">
                    <div className="w-full md:w-2/5">
                        <div className="border-b border-gray-400 h-16 flex items-end pb-2 mb-2 font-serif text-lg md:text-xl italic text-gray-500">[Signature]</div>
                        <p className="font-bold mt-2">{data.agreementDetails?.preparedBy}</p>
                        <p className="text-sm text-gray-600">Consultant</p>
                    </div>
                    <div className="w-full md:w-2/5">
                        <div className="border-b border-gray-400 h-16 flex items-end pb-2 mb-2 font-serif text-lg md:text-xl italic text-gray-500">[Signature]</div>
                        <p className="font-bold mt-2">{data.agreementDetails?.acceptedBy}</p>
                    </div>
                </div>
                <p className="mt-12 md:mt-16 text-gray-500">{data.agreementDetails?.date}</p>
            </div>
        );

    case 'thank_you':
      return (
        <div className="relative w-full h-full text-white flex items-center">
          <div className="absolute inset-0 bg-black opacity-50"></div>
          <img src={data.backgroundImage} alt="background" className="absolute inset-0 w-full h-full object-cover -z-10" />
          <div className="relative z-10 w-full p-8 md:p-12 lg:p-20">
              <div className="w-16 h-1 bg-orange-500 mb-8"></div>
              <h1 className="font-serif text-6xl sm:text-7xl md:text-8xl lg:text-9xl">{data.title}</h1>
          </div>
        </div>
      );

    default:
      return <div className="p-8 bg-gray-100">Unknown slide layout</div>;
  }
};


const Slide: React.FC<SlideProps> = ({ data }) => {
  return <div className="w-full h-full overflow-hidden">{renderLayout(data)}</div>;
};

export default Slide;