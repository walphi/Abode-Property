import React from 'react';

interface NavigationProps {
  onPrev: () => void;
  onNext: () => void;
  current: number;
  total: number;
}

const Navigation: React.FC<NavigationProps> = ({ onPrev, onNext, current, total }) => {
  return (
    <>
      {/* Top Bar */}
      <div className="absolute top-0 left-0 right-0 z-20 flex justify-end items-center p-4 md:p-6 text-white mix-blend-difference">
        <div className="flex items-center space-x-4">
            <span className="font-sans text-sm">{`Slide ${current} of ${total}`}</span>
            <button className="w-8 h-8 flex flex-col justify-around" aria-label="Menu">
                <span className="block w-full h-0.5 bg-white"></span>
                <span className="block w-full h-0.5 bg-white"></span>
                <span className="block w-full h-0.5 bg-white"></span>
            </button>
        </div>
      </div>

      {/* Bottom Controls */}
      <div className="absolute bottom-4 right-4 md:bottom-6 md:right-6 z-20 flex space-x-2">
        <button
          onClick={onPrev}
          className="w-12 h-12 bg-black bg-opacity-30 text-white rounded-full flex items-center justify-center hover:bg-opacity-50 transition-colors"
          aria-label="Previous Slide"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <button
          onClick={onNext}
          className="w-12 h-12 bg-black bg-opacity-30 text-white rounded-full flex items-center justify-center hover:bg-opacity-50 transition-colors"
          aria-label="Next Slide"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </button>
      </div>
    </>
  );
};

export default Navigation;